export type AppLanguage = "ar" | "en";

// Comprehensive Dictionary for the Entire ERP & POS Suite
export const AR_TO_EN_DICTIONARY: Record<string, string> = {
  // Brand & Application Names
  "نظام إدارة المطاعم والمحاسبة ERP": "Restaurant & Accounting ERP System",
  "نظام الإدارة المتكامل": "Integrated Management System",
  "نظام Restocash المتكامل": "Restocash Integrated System",
  "إدارة المطعم (البرنامج الشامل)": "Restaurant Management (Full Suite)",
  "إدارة المول والحديقة": "Mall & Park Management",
  "تصميم وإدارة الإيصالات والسندات": "Receipts & Vouchers Designer",
  "المستخدمين وحساباتهم": "Users & Access Accounts",
  "شاشة المطبخ والتحضير": "Kitchen & Prep Screen",
  "شاشة الكابتن": "Captain Ordering Screen",
  "نقطة بيع المطعم": "Restaurant POS",
  "نقطة بيع تذاكر الحديقة": "Park Tickets POS",
  "العودة لنقطة البيع": "Back to POS",
  "العودة للمطعم": "Back to Restaurant",
  "العودة للرئيسية": "Back to Home",
  "فتح القائمة الجانبية": "Open Sidebar Menu",
  "عملة عرض اللوحة:": "Display Currency:",
  "عملة العرض:": "Display Currency:",
  "لغة التطبيق:": "App Language:",
  "خيارات المطور": "Developer Options",
  "تسجيل الخروج": "Sign Out",
  "تسجيل الدخول": "Sign In",

  // Navigation Items
  "لوحة التحكم": "Dashboard",
  "لوحة الإدارة": "Admin Panel",
  "لوحة التحكم الرئيسية": "Main Control Panel",
  الرئيسية: "Home / Dashboard",
  "إدارة المطعم": "Restaurant",
  "إدارة المول": "Mall Management",
  "إدارة الحديقة": "Park Management",
  "إدارة الخزائن": "Treasuries",
  "إدارة الحسابات": "Accounts",
  "حساب الأستاذ": "General Ledger",
  "الموارد البشرية": "HR",
  "إدارة الموارد البشرية": "Human Resources",
  "إدارة المخزون": "Inventory",
  "إدارة الطاولات": "Tables Management",
  "إدارة المنيو": "Menu Management",
  التقارير: "Reports",
  "التقارير المالية": "Financial Reports",
  المستخدمين: "Users",
  المخازن: "Warehouses",
  الموردين: "Suppliers",
  المشتريات: "Purchases",

  // General Controls & Actions
  "بحث بالسرعة (تاريخ، رقم قيد MM/NN، رقم فاتورة)...":
    "Quick search (Date, Journal #, Invoice #)...",
  "بحث بالسرعة": "Quick Search",
  "بحث سريع...": "Quick search...",
  "بحث...": "Search...",
  بحث: "Search",
  تصفية: "Filter",
  "حفظ التغييرات": "Save Changes",
  "حفظ البيانات": "Save Data",
  حفظ: "Save",
  إلغاء: "Cancel",
  تعديل: "Edit",
  حذف: "Delete",
  "إضافة جديد": "Add New",
  إضافة: "Add",
  تأكيد: "Confirm",
  "إغلاق النافذة": "Close Window",
  إغلاق: "Close",
  "طباعة المستند": "Print Document",
  "طباعة التقرير": "Print Report",
  "طباعة الفاتورة": "Print Invoice",
  "طباعة الإيصال": "Print Receipt",
  "طباعة السند": "Print Voucher",
  طباعة: "Print",
  "تصدير Excel": "Export Excel",
  "تصدير PDF": "Export PDF",
  تصدير: "Export",
  استيراد: "Import",
  تحديث: "Refresh",
  "عرض التفاصيل": "View Details",
  "عرض السجل:": "View Log:",
  عرض: "View",
  معاينة: "Preview",
  تفاصيل: "Details",
  الإجراءات: "Actions",
  العمليات: "Operations",
  الحالة: "Status",
  الكل: "All",
  التاريخ: "Date",
  الوقت: "Time",
  العملة: "Currency",
  المبلغ: "Amount",
  الإجمالي: "Total",
  المجموع: "Total",
  "المجموع الفرعي": "Subtotal",
  الضريبة: "Tax",
  الخصم: "Discount",
  الصافي: "Net",
  الرصيد: "Balance",
  ملاحظات: "Notes",
  البيان: "Description / Memo",
  العميل: "Customer",
  المورد: "Supplier",
  الموظف: "Employee",
  الكاشير: "Cashier",
  "اسم الكاشير": "Cashier Name",
  "أمين الصندوق": "Cashier",
  "رقم الهاتف": "Phone Number",
  العنوان: "Address",
  "البريد الإلكتروني": "Email",

  // Dates & Presets
  "تحديد التاريخ من التقويم": "Pick Date from Calendar",
  "تصفية حسب التاريخ": "Filter by Date",
  "مسح تصفية التاريخ": "Clear Date Filter",
  "مسح التاريخ": "Clear Date",
  مسح: "Clear",
  اليوم: "Today",
  أمس: "Yesterday",
  "هذا الأسبوع": "This Week",
  "هذا الشهر": "This Month",
  "الشهر السابق": "Last Month",
  "هذا العام": "This Year",
  "من تاريخ": "From Date",
  "إلى تاريخ": "To Date",
  "كل الفترات": "All Dates",

  // Mall, Park & Shifts
  "حركات الفواتير والتذاكر": "Invoice & Ticket Transactions",
  "القيود المحاسبية (MM/NN)": "Journal Entries (MM/NN)",
  "القيود المحاسبية": "Journal Entries",
  "الورديات المغلقة": "Closed Shifts",
  "الورديات المفتوحة": "Open Shifts",
  "تذاكر الحديقة": "Park Tickets",
  "الرقم الفعلي (النظام)": "Actual # (System)",
  "الرقم الآخر (قابل للتعديل)": "Other # (Editable)",
  "الرقم الآخر (رقم السند أو الإيصال اليدوي القابل للتعديل):":
    "Other # (Editable Voucher/Manual Receipt #):",
  "المعامل (إذا كانت غير الدولار)": "Exchange Rate (Non-USD)",
  "المبلغ بالعملة": "Amount in Currency",
  "المعادل ($)": "USD Equivalent ($)",
  "المعادل بالدولار ($)": "USD Equivalent ($)",
  "العميل / البيان": "Customer / Description",
  "رقم القيد (MM/NN)": "Journal Ref (MM/NN)",
  "فتح وردية جديدة": "Open New Shift",
  "إغلاق الوردية": "Close Shift",
  "تقرير الوردية": "Shift Report",
  "تقرير إغلاق الوردية": "Shift Closing Report",
  "تقرير ومعاينة إغلاق الوردية": "Shift Closing Report & Preview",
  "تقرير الوردية المغلقة والقيود المحاسبية": "Closed Shift Report & Journal Entries",
  "تأكيد إغلاق الوردية وترحيل الأرصدة وتوليد القيود":
    "Confirm Shift Close, Transfer & Post Journals",
  "تأكيد إغلاق الوردية وتوليد القيود": "Confirm Shift Close & Generate Journals",
  "اختيار الوردية للاستعراض والتقرير:": "Select Shift for Review & Report:",
  "إجمالي المبيعات": "Gross Sales",
  "إجمالي المرتجعات": "Total Refunds",
  "صافي الإيراد المحصل": "Net Collected Revenue",
  "الخزائن التشغيلية": "Operational Treasuries",
  "الخزائن الرئيسية": "Main Treasuries",
  "الخزينة التشغيلية": "Operational Treasury",
  "الخزينة الرئيسية": "Main Treasury",
  "الرصيد المحصل": "Collected Balance",
  "تحويلات الخزائن المنجزة إلى الخزائن الرئيسية:": "Completed Transfers to Main Treasuries:",
  "المحلات والمستأجرين": "Shops & Tenants",
  المحلات: "Shops",
  المستأجرين: "Tenants",
  "عقود الإيجار": "Lease Contracts",
  "إنشاء عقد جديد": "Create New Contract",
  "اسم المستأجر": "Tenant Name",
  "رقم المحل / الوحدة": "Shop / Unit #",
  "رقم المحل": "Shop #",
  "نوع النشاط التجاري": "Business Activity",
  الطابق: "Floor",
  "المساحة (متر مربع)": "Area (sqm)",
  "تاريخ بداية العقد": "Contract Start Date",
  "تاريخ نهاية العقد": "Contract End Date",
  "الإيجار الشهري ($)": "Monthly Rent ($)",
  "الإيجار الشهري": "Monthly Rent",
  "مبلغ التأمين ($)": "Security Deposit ($)",
  "مبلغ التأمين": "Security Deposit",
  "تاريخ الاستحقاق": "Payment Due Date",
  "مدة الإيجار": "Lease Term",
  "خيار التجديد": "Renewal Option",
  "رسوم الخدمات": "Service Charges",
  "الزيادة السنوية": "Annual Escalation",
  "المرافق المشمولة": "Utilities Included",
  الكهرباء: "Electricity",
  المياه: "Water",
  "رسوم أخرى": "Other Charges",
  "بنود وشروط العقد": "Contract Terms & Conditions",
  "معاينة وطباعة العقد": "Preview & Print Contract",
  "سند قبض إيجار": "Rent Receipt Voucher",
  "سند صرف": "Payment Voucher",
  "سند قبض": "Receipt Voucher",

  // Accounting & Financial
  "شجرة الحسابات": "Chart of Accounts",
  "دليل الحسابات": "Chart of Accounts",
  "قيود اليومية العامة": "General Journal Entries",
  "قيد يومية جديد": "New Journal Entry",
  "رقم القيد": "Journal Ref #",
  "الرقم المرجعي": "Reference #",
  المرجع: "Reference",
  "تاريخ القيد": "Entry Date",
  "حساب المدين": "Debit Account",
  "حساب الدائن": "Credit Account",
  مدين: "Debit",
  دائن: "Credit",
  "إجمالي المدين": "Total Debit",
  "إجمالي الدائن": "Total Credit",
  "الفرق (التوازن)": "Balance Difference",
  "القيد متوازن": "Balanced",
  "القيد غير متوازن": "Unbalanced",
  "ميزان المراجعة": "Trial Balance",
  "قائمة الدخل (الأرباح والخسائر)": "Income Statement (P&L)",
  "قائمة المركز المالي (الميزانية العمومية)": "Balance Sheet",
  "كشف حساب": "Statement of Account",
  "الأصول المتداولة": "Current Assets",
  "الأصول الثابتة": "Fixed Assets",
  الأصول: "Assets",
  "الخصوم المتداولة": "Current Liabilities",
  الخصوم: "Liabilities",
  "حقوق الملكية": "Equity",
  "إيرادات النشاط": "Operating Revenues",
  الإيرادات: "Revenues",
  "تكلفة المبيعات": "Cost of Goods Sold (COGS)",
  "المصروفات التشغيلية": "Operating Expenses",
  المصروفات: "Expenses",
  "صافي الربح / الخسارة": "Net Profit / Loss",
  "ترحيل القيود": "Post Entries",
  مرحل: "Posted",
  "غير مرحل": "Unposted",

  // Treasury & Cashier
  "خزينة الكاشير": "Cashier Treasury",
  "الخزائن التشغيلية الثمانية": "8 Operational Treasuries",
  "الخزينة الرئيسية بالدولار": "Main USD Treasury",
  "الخزينة الرئيسية بالجنوب سوداني": "Main SSP Treasury",
  "الخزينة الرئيسية بالمصري": "Main EGP Treasury",
  "تحويل بين الخزائن": "Inter-Treasury Transfer",
  "حركة الخزينة": "Treasury Transaction",
  إيداع: "Deposit",
  سحب: "Withdrawal",
  تحويل: "Transfer",
  "الرصيد الافتتاحي": "Opening Balance",
  "الرصيد الحالي": "Current Balance",
  "الرصيد النهائي": "Ending Balance",
  "سعر الصرف اليومي": "Daily Exchange Rate",
  "سعر الصرف": "Exchange Rate",
  "أسعار الصرف": "Exchange Rates",

  // POS & Restaurant
  "نقطة البيع": "Point of Sale",
  "السلة والطلب": "Cart & Order",
  "سلة المشتريات فارغة": "Cart is empty",
  "داخل المطعم": "Dine-in",
  صالة: "Dine-in",
  سفري: "Takeaway",
  توصيل: "Delivery",
  "إضافة للطلب": "Add to Order",
  "تأكيد وإرسال الطلب": "Confirm & Send Order",
  "تأكيد الطلب والدفع": "Confirm & Pay",
  "طلب جديد": "New Order",
  "رقم الطلب": "Order #",
  "رقم الفاتورة": "Invoice #",
  "رقم الطاولة": "Table #",
  "اختر طاولة": "Choose Table",
  "نوع الطلب": "Order Type",
  "طريقة الدفع": "Payment Method",
  نقدي: "Cash",
  بطاقة: "Card / POS",
  "فيزا / بطاقة": "Card",
  محفظة: "Digital Wallet",
  "محفظة إلكترونية": "E-Wallet",
  "ملاحظات الطلب والطلبات الخاصة": "Order Notes & Requests",
  "مثال: بدون بصل، زيادة كاتشب...": "e.g., No onions, extra sauce...",
  "الإضافات المتوفرة": "Available Additions",
  "اختر الإضافات...": "Select Additions...",
  الأصناف: "Items",
  المنيو: "Menu",
  "قائمة الطعام": "Food Menu",
  الطاولات: "Tables",
  الطلبات: "Orders",
  "متابعة الطلبات": "Orders Tracking",
  "المطبخ / الفرن": "Kitchen / Oven",
  التحضير: "Preparing",
  جاهز: "Ready",
  "تم التقديم": "Served",
  معلق: "Pending",
  ملغي: "Cancelled",
  مدفوع: "Paid",
  مكتمل: "Completed",
  "تم الاستلام": "Received",
  "قيد التحضير": "In Progress",

  // HR & Employees
  "إضافة موظف": "Add Employee",
  "اسم الموظف": "Employee Name",
  "المسمى الوظيفي": "Job Title",
  القسم: "Department",
  "الراتب الأساسي": "Base Salary",
  "الحوافز والمكافآت": "Incentives & Bonuses",
  "الخصومات والجزاءات": "Deductions & Penalties",
  "صافي الراتب": "Net Salary",
  "سجل الحضور والانصراف": "Attendance Log",
  "صرف الرواتب": "Disburse Salaries",
  "اسم المستخدم": "Username",
  "كلمة المرور": "Password",
  الصلاحيات: "Permissions",
  "مدير عام": "Super Admin",
  كاشير: "Cashier",
  "كابتن صالة": "Floor Captain",
  محاسب: "Accountant",
  "أمين مخزن": "Storekeeper",

  // Receipts, Printing & Invoices
  "فاتورة ضريبية مبسطة": "Simplified Tax Invoice",
  "إيصال استلام نقدية": "Cash Receipt Voucher",
  "إيصال صرف نقدية": "Cash Payment Voucher",
  "سند قبض رسمي": "Official Receipt Voucher",
  "سند صرف رسمي": "Official Payment Voucher",
  "شكراً لزيارتكم — نتشرّف بخدمتكم دائماً": "Thank you for your visit — Always at your service",
  "شكراً لزيارتكم": "Thank you for your visit",
  "نسخة العميل": "Customer Copy",
  "نسخة الإدارة": "Management Copy",
  "نسخة الحسابات": "Accounts Copy",
  التوقيع: "Signature",
  الختم: "Stamp / Seal",
  المستلم: "Receiver",
  "المحاسب المسؤول": "Accountant in Charge",
  "المدير المالي": "Finance Manager",
  "أمين الخزينة": "Treasurer / Cashier",

  // Dialogs & Messages
  "هل أنت متأكد؟": "Are you sure?",
  "تم الحفظ بنجاح": "Saved successfully",
  "تمت العملية بنجاح": "Operation completed successfully",
  "حدث خطأ أثناء العملية": "An error occurred",
  "يرجى ملء جميع الحقول المطلوبة": "Please fill all required fields",
  "جاري التحميل...": "Loading...",
  "لا توجد بيانات متاحة": "No data available",
  "لا توجد سجلات مطابقة": "No matching records found",
  "عرض المزيد": "View More",
  رجوع: "Back",
  التالي: "Next",
  السابق: "Previous",
};

// Sorted list of Arabic phrases (longest first) for substring replacement
const SORTED_AR_ENTRIES: [string, string][] = Object.entries(AR_TO_EN_DICTIONARY).sort(
  (a, b) => b[0].length - a[0].length,
);

// Map to remember original text on DOM nodes
const nodeOriginalTextMap = new WeakMap<Node, string>();
const elementOriginalAttributesMap = new WeakMap<
  HTMLElement,
  { placeholder?: string; title?: string; ariaLabel?: string }
>();

export class TranslationService {
  private currentLang: AppLanguage = "ar";
  private isObserving = false;
  private isTranslating = false;
  private observer: MutationObserver | null = null;

  constructor() {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("app_lang") as AppLanguage;
      this.currentLang = stored === "en" ? "en" : "ar";
    }
  }

  getLanguage(): AppLanguage {
    return this.currentLang;
  }

  setLanguage(lang: AppLanguage): void {
    this.currentLang = lang;
    if (typeof window !== "undefined") {
      localStorage.setItem("app_lang", lang);
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";

      if (lang === "en") {
        this.applyFullTranslation();
      } else {
        this.restoreFullArabic();
      }

      window.dispatchEvent(new CustomEvent("app_lang_changed", { detail: { lang } }));
    }
  }

  // React translation helper function
  t(text: string, forceLang?: AppLanguage): string {
    if (!text || typeof text !== "string") return text;
    const targetLang = forceLang || this.currentLang;
    if (targetLang === "ar") return text;

    let result = text;
    for (const [arPhrase, enPhrase] of SORTED_AR_ENTRIES) {
      if (result.includes(arPhrase)) {
        result = result.split(arPhrase).join(enPhrase);
      }
    }
    return result;
  }

  translateTextString(arabicText: string): string {
    if (!arabicText || !arabicText.trim()) return arabicText;
    let translated = arabicText;
    for (const [arPhrase, enPhrase] of SORTED_AR_ENTRIES) {
      if (translated.includes(arPhrase)) {
        translated = translated.split(arPhrase).join(enPhrase);
      }
    }
    return translated;
  }

  translateNode(node: Node): void {
    if (this.isTranslating) return;

    if (node.nodeType === Node.TEXT_NODE) {
      const textNode = node as Text;
      const text = textNode.nodeValue || "";
      if (!text.trim()) return;

      // Remember original Arabic text if not saved yet
      if (!nodeOriginalTextMap.has(textNode)) {
        nodeOriginalTextMap.set(textNode, text);
      }

      const origText = nodeOriginalTextMap.get(textNode) || text;
      const translated = this.translateTextString(origText);
      if (translated !== textNode.nodeValue) {
        textNode.nodeValue = translated;
      }
      return;
    }

    if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as HTMLElement;
      if (
        el.tagName === "SCRIPT" ||
        el.tagName === "STYLE" ||
        el.tagName === "NOSCRIPT" ||
        el.classList?.contains("no-translate")
      ) {
        return;
      }

      // Handle input / textarea placeholders
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        if (!elementOriginalAttributesMap.has(el)) {
          elementOriginalAttributesMap.set(el, {
            placeholder: el.placeholder,
            title: el.title,
          });
        }
        const orig = elementOriginalAttributesMap.get(el);
        if (orig?.placeholder) {
          el.placeholder = this.translateTextString(orig.placeholder);
        }
      }

      // Handle title
      if (el.title) {
        if (!elementOriginalAttributesMap.has(el)) {
          elementOriginalAttributesMap.set(el, { title: el.title });
        }
        const orig = elementOriginalAttributesMap.get(el);
        if (orig?.title) {
          el.title = this.translateTextString(orig.title);
        }
      }

      // Traverse children
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      let currTextNode: Node | null;
      while ((currTextNode = walker.nextNode())) {
        const textNode = currTextNode as Text;
        const text = textNode.nodeValue || "";
        if (!text.trim()) continue;

        if (!nodeOriginalTextMap.has(textNode)) {
          nodeOriginalTextMap.set(textNode, text);
        }

        const origText = nodeOriginalTextMap.get(textNode) || text;
        const translated = this.translateTextString(origText);
        if (translated !== textNode.nodeValue) {
          textNode.nodeValue = translated;
        }
      }
    }
  }

  restoreNode(node: Node): void {
    if (node.nodeType === Node.TEXT_NODE) {
      const textNode = node as Text;
      if (nodeOriginalTextMap.has(textNode)) {
        const orig = nodeOriginalTextMap.get(textNode);
        if (orig !== undefined && textNode.nodeValue !== orig) {
          textNode.nodeValue = orig;
        }
      }
      return;
    }

    if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as HTMLElement;
      if (elementOriginalAttributesMap.has(el)) {
        const orig = elementOriginalAttributesMap.get(el);
        if (orig?.placeholder && el instanceof HTMLInputElement) {
          el.placeholder = orig.placeholder;
        }
        if (orig?.title) {
          el.title = orig.title;
        }
      }

      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      let currTextNode: Node | null;
      while ((currTextNode = walker.nextNode())) {
        const textNode = currTextNode as Text;
        if (nodeOriginalTextMap.has(textNode)) {
          const orig = nodeOriginalTextMap.get(textNode);
          if (orig !== undefined && textNode.nodeValue !== orig) {
            textNode.nodeValue = orig;
          }
        }
      }
    }
  }

  applyFullTranslation(): void {
    if (typeof document === "undefined") return;
    this.isTranslating = true;
    try {
      this.translateNode(document.body);
    } finally {
      this.isTranslating = false;
    }
  }

  restoreFullArabic(): void {
    if (typeof document === "undefined") return;
    this.isTranslating = true;
    try {
      this.restoreNode(document.body);
    } finally {
      this.isTranslating = false;
    }
  }

  start(): void {
    if (typeof window === "undefined" || this.isObserving) return;

    const stored = localStorage.getItem("app_lang") as AppLanguage;
    this.currentLang = stored === "en" ? "en" : "ar";
    document.documentElement.lang = this.currentLang;
    document.documentElement.dir = this.currentLang === "ar" ? "rtl" : "ltr";

    this.observer = new MutationObserver((mutations: MutationRecord[]) => {
      if (this.currentLang !== "en" || this.isTranslating) return;
      this.isTranslating = true;
      try {
        mutations.forEach((mutation) => {
          if (mutation.type === "childList") {
            mutation.addedNodes.forEach((node) => {
              this.translateNode(node);
            });
          } else if (mutation.type === "characterData") {
            this.translateNode(mutation.target);
          }
        });
      } finally {
        this.isTranslating = false;
      }
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
    });

    if (this.currentLang === "en") {
      this.applyFullTranslation();
    }
    this.isObserving = true;
  }
}

export const translator = new TranslationService();
