const fs = require('fs');

function fix(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/              tx\.treasury_id = "tr-1";\n          \n        \);\n      /g, '              tx.treasury_id = "tr-1";\n            }\n          });\n        }');
  fs.writeFileSync(file, content);
}
fix('src/shared/services/erpStore.ts');
fix('src/shared/services/erpStore.fixed.ts');
