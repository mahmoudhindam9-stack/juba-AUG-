const fs = require('fs');
let content = fs.readFileSync('src/shared/services/erpStore.ts', 'utf8');

const replacement = `        const parsed = JSON.parse(raw);

        // HARD RESET: Delete all transactions and zero all balances
        if (!parsed.hard_reset_2026_08_18) {
          parsed.hard_reset_2026_08_18 = true;
          parsed.treasuryTransactions = [];
          parsed.journalEntries = [];
          parsed.vouchers = [];
          parsed.purchaseOrders = [];
          parsed.inventoryDocuments = [];
          
          if (parsed.treasuries) {
            parsed.treasuries.forEach((t) => {
              t.balance = 0;
              t.opening_balance = 0;
              t.available_balance = 0;
              if (t.containers) {
                t.containers.forEach((c) => {
                  c.balance = 0;
                });
              }
            });
          }
          if (parsed.accounts) {
            parsed.accounts.forEach((a) => {
              a.balance = 0;
              a.opening_balance = 0;
            });
          }
          if (typeof localStorage !== "undefined") {
             localStorage.removeItem("pos_local_orders");
          }
        }`;

content = content.replace('        const parsed = JSON.parse(raw);', replacement);
fs.writeFileSync('src/shared/services/erpStore.ts', content);

let fixedContent = fs.readFileSync('src/shared/services/erpStore.fixed.ts', 'utf8');
fixedContent = fixedContent.replace('        const parsed = JSON.parse(raw);', replacement);
fs.writeFileSync('src/shared/services/erpStore.fixed.ts', fixedContent);

console.log("Replaced");
