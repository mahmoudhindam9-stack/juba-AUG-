const fs = require('fs');
const code = fs.readFileSync('src/shared/services/erpStore.fixed.ts', 'utf8');
const lines = code.split('\n');

let count = 0;
for (let i = 3453; i < 4750; i++) {
  count += (lines[i].match(/\{/g) || []).length;
  count -= (lines[i].match(/\}/g) || []).length;
  console.log(`Line ${i+1}: count=${count} | ${lines[i]}`);
  if (count <= 0 && i > 3454) {
    console.log("CLOSED AT LINE", i + 1);
    break;
  }
}
