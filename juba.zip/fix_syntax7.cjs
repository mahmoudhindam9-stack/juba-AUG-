const fs = require('fs');
function fix(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/    if \(typeof window === "undefined" \|\| typeof localStorage === "undefined"\) {\n      return this\.getDefaultState\(\);\n      const raw = localStorage\.getItem\("erp_store_state"\);/g, '    if (typeof window === "undefined" || typeof localStorage === "undefined") {\n      return this.getDefaultState();\n    }\n    const raw = localStorage.getItem("erp_store_state");');
  fs.writeFileSync(file, content);
}
fix('src/shared/services/erpStore.ts');
fix('src/shared/services/erpStore.fixed.ts');
