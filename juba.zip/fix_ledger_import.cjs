const fs = require('fs');
let content = fs.readFileSync('src/routes/admin/ledger.tsx', 'utf8');

// Replace the fallback currency
content = content.replace(/let currency = rawCurrency \|\| 'EGP';/g, "let currency = rawCurrency || 'USD';");

// Add exchange_rate to mapped object
content = content.replace(
  /main_description: row\[18\] \|\| row\[17\] \|\| row\[5\] \|\| "",\s*bal_trx: "TRX" \/\/ By default mark all as TRX based on this sheet format/g,
  'main_description: row[18] || row[17] || row[5] || "",\n              exchange_rate: Number(row[21]) || 1,\n              original_index: index,\n              bal_trx: "TRX" // By default mark all as TRX based on this sheet format'
);

// We need to add 'index' to the map function: `.map((row) => {` -> `.map((row, index) => {`
content = content.replace(/const validData = dataRows\.map\(row => \{/g, 'const validData = dataRows.map((row, index) => {');

// Fix the currency fallback in the entry creation
content = content.replace(/currency: \(firstLine\.currency \|\| 'EGP'\) as any,/g, "currency: (firstLine.currency || 'USD') as any,");
content = content.replace(/currency: \(l\.currency \|\| 'EGP'\) as any,/g, "currency: (l.currency || 'USD') as any,");
content = content.replace(/rate: 1,/g, 'rate: l.exchange_rate || 1,');

// Maintain order of journal entries by sorting the keys by the minimum original_index of their lines
content = content.replace(
  /Object\.keys\(groups\)\.forEach\(\(jNum\) => \{/g,
  `Object.keys(groups).sort((a, b) => groups[a][0].original_index - groups[b][0].original_index).forEach((jNum) => {`
);

// Add sequence to the created entry to maintain order if the system relies on it
content = content.replace(
  /newEntries\.push\(\{/g,
  'newEntries.push({'
);

fs.writeFileSync('src/routes/admin/ledger.tsx', content);
