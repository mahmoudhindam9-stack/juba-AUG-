const fs = require('fs');
function fix(file) {
  let content = fs.readFileSync(file, 'utf8');
  let bad = `    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      localStorage.removeItem("pos_local_orders");
  
    this.recalculateAccountBalances();
    if (typeof window !== "undefined") {
      setTimeout(() => this.saveState(), 1000);`;
  
  let good = `    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      localStorage.removeItem("pos_local_orders");
    }
  
    this.recalculateAccountBalances();
    if (typeof window !== "undefined") {
      setTimeout(() => this.saveState(), 1000);
    }
  }`;
  content = content.replace(bad, good);
  
  // Try another version without newlines
  let bad2 = `    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      localStorage.removeItem("pos_local_orders");
    this.recalculateAccountBalances();
    if (typeof window !== "undefined") {
      setTimeout(() => this.saveState(), 1000);`;
  content = content.replace(bad2, good);
  
  fs.writeFileSync(file, content);
}
fix('src/shared/services/erpStore.ts');
fix('src/shared/services/erpStore.fixed.ts');
