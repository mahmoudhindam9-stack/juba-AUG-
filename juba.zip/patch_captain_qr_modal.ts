import fs from "fs";

const path = "src/routes/captain.tsx";
let content = fs.readFileSync(path, "utf8");

const qrModal = `

      {/* Self-Ordering QR Code Generator */}
      <Dialog open={isQrModalOpen} onOpenChange={setIsQrModalOpen}>
        <DialogContent dir={lang === "ar" ? "rtl" : "ltr"} className="sm:max-w-md bg-white">
          <DialogHeader className={lang === "ar" ? "text-right" : "text-left"}>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="text-indigo-600" />
              {lang === "ar" ? "باركود الطلب الذاتي" : "Self-Ordering QR Code"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4 print:hidden">
            <div className="space-y-2">
              <Label className={lang === "ar" ? "text-right block" : "text-left block"}>
                {lang === "ar" ? "رقم الطاولة (اختياري)" : "Table Number (Optional)"}
              </Label>
              <Input
                value={qrTableNumber}
                onChange={(e) => setQrTableNumber(e.target.value)}
                placeholder={lang === "ar" ? "مثال: 5" : "e.g. 5"}
                className={lang === "ar" ? "text-right" : "text-left"}
              />
            </div>
            <div className="space-y-2">
              <Label className={lang === "ar" ? "text-right block" : "text-left block"}>
                {lang === "ar" ? "رسالة الترحيب" : "Welcome Message"}
              </Label>
              <Input
                value={qrWelcomeMessage}
                onChange={(e) => setQrWelcomeMessage(e.target.value)}
                className={lang === "ar" ? "text-right" : "text-left"}
              />
            </div>
          </div>
          
          <div className="flex flex-col items-center justify-center p-6 bg-slate-50 rounded-2xl border border-slate-100" id="print-qr-area">
            <h3 className="text-lg font-black text-slate-800 mb-1">
              {qrWelcomeMessage || (lang === "ar" ? "أهلاً بك!" : "Welcome!")}
            </h3>
            {qrTableNumber && (
              <p className="text-sm font-bold text-slate-500 mb-4">
                {lang === "ar" ? \`طاولة رقم \${qrTableNumber}\` : \`Table #\${qrTableNumber}\`}
              </p>
            )}
            {!qrTableNumber && <div className="mb-4" />}
            
            <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200">
              <QRCodeSVG 
                value={\`\${window.location.origin}/menu\${qrTableNumber ? \`?table=\${qrTableNumber}\` : ''}\`} 
                size={200} 
                level={"H"}
                includeMargin={true}
              />
            </div>
            <p className="text-xs text-slate-400 mt-4 text-center">
              {lang === "ar" ? "قم بمسح الباركود للطلب المباشر" : "Scan QR code to order directly"}
            </p>
          </div>

          <DialogFooter className="sm:justify-between mt-4">
            <Button variant="outline" onClick={() => setIsQrModalOpen(false)} className="print:hidden">
              {lang === "ar" ? "إغلاق" : "Close"}
            </Button>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700 text-white gap-2 print:hidden"
              onClick={() => {
                const printContent = document.getElementById("print-qr-area");
                if (printContent) {
                  const originalContents = document.body.innerHTML;
                  document.body.innerHTML = \`<div style="display:flex;justify-content:center;align-items:center;height:100vh;flex-direction:column;font-family:sans-serif;">\${printContent.innerHTML}</div>\`;
                  window.print();
                  document.body.innerHTML = originalContents;
                  window.location.reload();
                }
              }}
            >
              <Printer size={16} />
              {lang === "ar" ? "طباعة الباركود" : "Print QR Code"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
`;

content = content.replace("    </div>\n  );\n}", qrModal);

fs.writeFileSync(path, content, "utf8");
