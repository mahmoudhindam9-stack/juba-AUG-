const fs = require('fs');
let file = 'src/shared/services/erpStore.ts';
let content = fs.readFileSync(file, 'utf8');
content = content.replace(/^,$/gm, '  },');
fs.writeFileSync(file, content);

let file2 = 'src/shared/services/erpStore.fixed.ts';
let content2 = fs.readFileSync(file2, 'utf8');
content2 = content2.replace(/^,$/gm, '  },');
fs.writeFileSync(file2, content2);
