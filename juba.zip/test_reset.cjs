const { createClient } = require("@supabase/supabase-js");
const supabaseUrl = process.env.VITE_SUPABASE_URL || "https://myqtvbfibvgxkqwxvuru.supabase.co";
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im15cXR2YmZpYnZneGtxd3h2dXJ1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ4MjY0NjgsImV4cCI6MjEwMDQwMjQ2OH0.LDFW826N2GRzG9WnLHgYxoeOcTkDOeLjTiFK6aQ-BSE";
const supabase = createClient(supabaseUrl, supabaseKey);

async function reset() {
  console.log("Deleting orders...");
  let { error: err1 } = await supabase.from("orders").delete().neq("id", "00000000-0000-0000-0000-000000000000");
  console.log("Orders:", err1 || "OK");

  console.log("Deleting inventory_transactions...");
  let { error: err2 } = await supabase.from("inventory_transactions").delete().neq("id", "00000000-0000-0000-0000-000000000000");
  console.log("Inventory tx:", err2 || "OK");
  
  // also inventory quantities to 0
  console.log("Updating inventory quantities...");
  let { error: err3 } = await supabase.from("inventory").update({ quantity: 0 }).neq("id", "00000000-0000-0000-0000-000000000000");
  console.log("Inventory qty:", err3 || "OK");
}
reset();
