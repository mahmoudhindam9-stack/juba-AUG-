const fs = require('fs');
function fix(file) {
  let content = fs.readFileSync(file, 'utf8');
  let bad = `        if (parsed.treasuryTransactions) {
          parsed.treasuryTransactions.forEach((tx: any) => {
            if (tx.treasury_id === "tr-300") {
              tx.treasury_id = "tr-1";
                  );`;
  let good = `        if (parsed.treasuryTransactions) {
          parsed.treasuryTransactions.forEach((tx: any) => {
            if (tx.treasury_id === "tr-300") {
              tx.treasury_id = "tr-1";
            }
          });
        }`;
  content = content.replace(bad, good);
  fs.writeFileSync(file, content);
}
fix('src/shared/services/erpStore.ts');
fix('src/shared/services/erpStore.fixed.ts');
