const fs = require('fs');

['src/routes/admin/mall.tsx', 'src/routes/admin/inventory.tsx', 'src/routes/admin/index.tsx', 'src/routes/admin/hr.tsx'].forEach(filePath => {
  let content = fs.readFileSync(filePath, 'utf8');
  content = content.replace(/\{t\.account_code \? `\[\$\{t\.account_code\}\] ` : ""\}\{t\.account_code \? `\[رقم الحساب: \$\{t\.account_code\}\] ` : ""\}/g, '{t.account_code ? `[رقم الحساب: ${t.account_code}] ` : ""}');
  fs.writeFileSync(filePath, content);
});

console.log('Fixed duplicates');
