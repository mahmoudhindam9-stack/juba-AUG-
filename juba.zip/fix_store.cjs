const fs = require('fs');

let lines = fs.readFileSync('src/shared/services/erpStore.ts', 'utf8').split('\n');
let newLines = [];

for (let i = 0; i < lines.length; i++) {
    let line = lines[i];

    if (line === "  ") { newLines.push("    }"); continue; }
    if (line === "    ") { newLines.push("      }"); continue; }
    if (line === "      ") { newLines.push("        }"); continue; }
    if (line === "        ") { newLines.push("          }"); continue; }
    if (line === "          ") { newLines.push("            }"); continue; }
    if (line === "            ") { newLines.push("              }"); continue; }
    
    if (line === "};") { newLines.push("  };"); continue; }
    if (line === ";") { newLines.push("  };"); continue; }
    if (line === "  ;") { newLines.push("    };"); continue; }
    if (line === "    ;") { newLines.push("      };"); continue; }
    if (line === "      ;") { newLines.push("        };"); continue; }

    if (line === ",") { newLines.push("  },"); continue; }
    if (line === "  ,") { newLines.push("    },"); continue; }
    if (line === "    ,") { newLines.push("      },"); continue; }
    if (line === "      ,") { newLines.push("        },"); continue; }

    if (line === ")") { newLines.push("  })"); continue; }
    if (line === "  )") { newLines.push("    })"); continue; }
    if (line === "    )") { newLines.push("      })"); continue; }
    if (line === "      )") { newLines.push("        })"); continue; }

    if (line === ");") { newLines.push("  });"); continue; }
    if (line === "  );") { newLines.push("    });"); continue; }
    if (line === "    );") { newLines.push("      });"); continue; }
    if (line === "      );") { newLines.push("        });"); continue; }

    if (line.match(/^ else \{/)) { newLines.push(line.replace(/^ else \{/, "  } else {")); continue; }
    if (line.match(/^   else \{/)) { newLines.push(line.replace(/^   else \{/, "    } else {")); continue; }
    if (line.match(/^     else \{/)) { newLines.push(line.replace(/^     else \{/, "      } else {")); continue; }
    if (line.match(/^       else \{/)) { newLines.push(line.replace(/^       else \{/, "        } else {")); continue; }

    if (line.match(/^ catch /)) { newLines.push(line.replace(/^ catch /, "  } catch ")); continue; }
    if (line.match(/^   catch /)) { newLines.push(line.replace(/^   catch /, "    } catch ")); continue; }
    if (line.match(/^     catch /)) { newLines.push(line.replace(/^     catch /, "      } catch ")); continue; }

    if (line === "[];") { newLines.push("  }[];"); continue; }
    if (line === "  [];") { newLines.push("    }[];"); continue; }

    newLines.push(line);
}

let finalLines = [];
let blockClosed = false;
for (let i = 0; i < newLines.length; i++) {
    if (newLines[i] === "") {
        let prev = "";
        for (let j = i - 1; j >= 0; j--) {
            if (newLines[j].trim() !== "") { prev = newLines[j]; break; }
        }
        let next = "";
        for (let j = i + 1; j < newLines.length; j++) {
            if (newLines[j].trim() !== "") { next = newLines[j]; break; }
        }
        
        let prevIndent = prev.length - prev.trimStart().length;
        let nextIndent = next.length - next.trimStart().length;
        
        if (prevIndent >= 4 && nextIndent <= 2 && !prev.endsWith("{") && !blockClosed) {
            finalLines.push("  }");
            blockClosed = true;
        } else {
            finalLines.push("");
        }
    } else {
        if (newLines[i].trim() !== "") blockClosed = false;
        finalLines.push(newLines[i]);
    }
}

fs.writeFileSync('src/shared/services/erpStore.fixed.ts', finalLines.join('\n'));
