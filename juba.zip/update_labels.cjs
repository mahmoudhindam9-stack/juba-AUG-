const fs = require('fs');
let indexFile = fs.readFileSync('src/routes/admin/index.tsx', 'utf8');

indexFile = indexFile.replace(
  /{t\.name_ar}/g,
  '{t.account_code ? `[رقم الحساب: ${t.account_code}] ` : ""}{t.name_ar}'
);
fs.writeFileSync('src/routes/admin/index.tsx', indexFile);


let accountsFile = fs.readFileSync('src/routes/admin/accounts.tsx', 'utf8');
accountsFile = accountsFile.replace(
  /ربط لحظي برصيد خزينة: {t\.name_ar} \({t\.currency}\)/g,
  '{t.account_code ? `[رقم الحساب: ${t.account_code}] ` : ""}ربط لحظي برصيد خزينة: {t.name_ar} ({t.currency})'
);
fs.writeFileSync('src/routes/admin/accounts.tsx', accountsFile);

let hrFile = fs.readFileSync('src/routes/admin/hr.tsx', 'utf8');
hrFile = hrFile.replace(
  /{t\.name_ar}/g,
  '{t.account_code ? `[رقم الحساب: ${t.account_code}] ` : ""}{t.name_ar}'
);
fs.writeFileSync('src/routes/admin/hr.tsx', hrFile);

let mallFile = fs.readFileSync('src/routes/admin/mall.tsx', 'utf8');
mallFile = mallFile.replace(
  /{t\.name_ar}/g,
  '{t.account_code ? `[رقم الحساب: ${t.account_code}] ` : ""}{t.name_ar}'
);
fs.writeFileSync('src/routes/admin/mall.tsx', mallFile);

let inventoryFile = fs.readFileSync('src/routes/admin/inventory.tsx', 'utf8');
inventoryFile = inventoryFile.replace(
  /{t\.name_ar} \(رصيد/g,
  '{t.account_code ? `[رقم الحساب: ${t.account_code}] ` : ""}{t.name_ar} (رصيد'
);
fs.writeFileSync('src/routes/admin/inventory.tsx', inventoryFile);

console.log('Update Complete');
