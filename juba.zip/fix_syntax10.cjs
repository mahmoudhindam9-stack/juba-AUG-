const fs = require('fs');

function fix(file) {
  let lines = fs.readFileSync(file, 'utf8').split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes('if (tx.treasury_id === "tr-300") {') && lines[i+2].includes('                  );')) {
      lines[i+1] = '              tx.treasury_id = "tr-1";';
      lines[i+2] = '            }';
      lines.splice(i+3, 0, '          });');
      lines.splice(i+4, 0, '        }');
      break;
    }
  }
  fs.writeFileSync(file, lines.join('\n'));
}
fix('src/shared/services/erpStore.ts');
fix('src/shared/services/erpStore.fixed.ts');
