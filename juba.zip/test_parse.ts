type JournalLine = any;
type TreasuryTransaction = any;
class ERPStore {
  inferMovementTypeFromLine(line: JournalLine, mainDesc: string = "", otherLines: JournalLine[] = []): TreasuryTransaction["type"] {
  }
}
