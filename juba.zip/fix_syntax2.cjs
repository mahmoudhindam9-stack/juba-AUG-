const fs = require('fs');
let content = fs.readFileSync('src/shared/services/erpStore.ts', 'utf8');

const replacement = `  items: {
    inventory_id: string;
    quantity: number;
    unit_cost: number;
    received_quantity?: number;
    returned_quantity?: number;
  }[];`;

content = content.replace(`  items: {
    inventory_id: string;
    quantity: number;
    unit_cost: number;
    received_quantity?: number;
    returned_quantity?: number;
[];`, replacement);

fs.writeFileSync('src/shared/services/erpStore.ts', content);

let content2 = fs.readFileSync('src/shared/services/erpStore.fixed.ts', 'utf8');
content2 = content2.replace(`  items: {
    inventory_id: string;
    quantity: number;
    unit_cost: number;
    received_quantity?: number;
    returned_quantity?: number;
[];`, replacement);
fs.writeFileSync('src/shared/services/erpStore.fixed.ts', content2);
