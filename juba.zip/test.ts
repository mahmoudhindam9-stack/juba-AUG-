class X {
  inferMovementTypeFromLine(line: any, mainDesc: string = "", otherLines: any[] = []): any {}
}
