const fs = require('fs');
function fix(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/            deleted: false,\n            containers: defaultSalesContainers,\n        ;/g, '            deleted: false,\n            containers: defaultSalesContainers,\n        };');
  fs.writeFileSync(file, content);
}
fix('src/shared/services/erpStore.ts');
fix('src/shared/services/erpStore.fixed.ts');
