import { Route } from "./src/routes/admin/index";
console.log(Route.options.component);
